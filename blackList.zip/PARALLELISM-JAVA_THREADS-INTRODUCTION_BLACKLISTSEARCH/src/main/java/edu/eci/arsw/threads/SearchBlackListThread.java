package edu.eci.arsw.threads;

import java.util.List;

import edu.eci.arsw.blacklistvalidator.HostBlackListsValidator;
import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;

public class SearchBlackListThread extends Thread {

    private int start;
    private int end;
    private String ip;
    private List<Integer> blackListOcurrences;
    private HostBlackListsValidator validator;

    public SearchBlackListThread(int start, int end, String ipaddress,
            List<Integer> blackListOcurrences,
            HostBlackListsValidator validator) {

        this.start = start;
        this.end = end;
        this.ip = ipaddress;  
        this.blackListOcurrences = blackListOcurrences; 
        this.validator = validator; 
    }

    @Override
    public void run() {

        HostBlacklistsDataSourceFacade skds =
                HostBlacklistsDataSourceFacade.getInstance();

        for (int i = start; i < end && !validator.Stop(); i++) {

            if (skds.isInBlackListServer(i, ip)) {

                blackListOcurrences.add(i);

                validator.increaseOccurrences();
            }
        }
    }
}
